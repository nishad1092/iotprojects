import asyncio
import time
import uuid
from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device import Message
from azure.iot.device import MethodResponse
import json

module_client = None


async def main():
    # Inputs/Ouputs are only supported in the context of Azure IoT Edge and module client
    # The module client object acts as an Azure IoT Edge module and interacts with an Azure IoT Edge hub
    global module_client
    module_client = IoTHubModuleClient.create_from_edge_environment()
    # global module_client
    # Connect the client.
    await module_client.connect()

    async def method_listener(module_client):
        while True:
            print("Module listener")
            method_request = await module_client.receive_method_request("")
            # Wait for unknown method calls
            # set response payload
            payload = {"result": True, "data": "Received"}
            status = 200  # set return status code
            print("executed method: " + method_request.name)
            # print("Payload" + method_request.payload)
            method_response = MethodResponse.create_from_method_request(
                method_request, status, payload
            )
            # send response
            await module_client.send_method_response(method_response)
            await send_test_message(method_request)

    # send response
    listeners = await asyncio.gather(method_listener(module_client))
    # asyncio.run(await send_test_message(2))
    listeners.cancel()

    # finally, disconnect
    await module_client.disconnect()


async def send_test_message(method_request):
    global module_client
    print("Invoking message to StreamModule")

    if method_request.name == "command":
        msgp = method_request.payload
        msgpayload = json.dumps(msgp)
        # msg = method_request.payload
        await module_client.send_message_to_output(msgpayload, "outputmsg")

   
    else:
        print("No can't invoke")


if __name__ == "__main__":
    asyncio.run(main())