import os
import asyncio
# import paho.mqtt.client as mqtt
# import paho.mqtt.publish as publish
import urllib3
import datetime
import json
import uuid
import time

from azure.iot.device.aio import IoTHubModuleClient
from azure.iot.device import Message


messages_to_send = 5

async def main():
    # The client object is used to interact with your Azure IoT hub.
    module_client = IoTHubModuleClient.create_from_edge_environment()


    await module_client.connect()

    async def stream_message(i):
       
        while True:

            value = "temperature: 30, Humidity: 90"

            print("sending message #" + str(i))
            msg = Message(value)
            msg.message_id = uuid.uuid4()
            msg.content_encoding = "utf-8"
            msg.content_type = "application/json"
            await module_client.send_message(msg)
            print("done sending message #" + str(i))

            # send `messages_to_send` messages in parallel
            await asyncio.gather(*[stream_message(i) for i in range(1, messages_to_send + 1)])

            # Finally, shut down the client
            await module_client.shutdown()

            
            # ----------- Receiving the Input from Invoke Module----------
            
            # print("Receiving Input to Invoke Module")
            # input_message = await module_client.receive_message_on_input("inputstream")
            # print(input_message)
            # print("raw incoming data", input_message)

            # # Checking incoming messagev
            # cloudmsg = input_message.data

            # cloudecode = cloudmsg.decode("ASCII")

            # cloudecode_json = json.loads(cloudecode)
            # cloud_json = json.loads(cloudecode_json)

            # print("Incoming cloud_decoded Message", cloud_json["command"])
            # if cloud_json["command"] == "getData":

            #     with open("/app/camera_path/camera_path.txt", "r+") as file:
            #         print("Reading the camera path")
                   

            # else:
            #     print("Unable to find command")



    # async def input2_listener(module_client):
    #     while True:
    #         # blocking call
    #         input_message = await module_client.receive_message_on_input("input2")
    #         print("the data in the message received on input2 was ")
    #         print(input_message.data)
    #         print("custom properties are")
    #         print(input_message.custom_properties)

    # # Schedule task for listeners
    # listeners = await asyncio.gather(input1_listener(module_client))

    # listeners.cancel()

    # Finally, disconnect
    # await module_client.disconnect()

if __name__ == "__main__":

    asyncio.run(main())
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(main())
